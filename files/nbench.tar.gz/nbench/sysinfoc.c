sprintf(buffer,"C compiler          : gcc version 4.9.2 (Debian 4.9.2-10) \n");
output_string(buffer);
sprintf(buffer,"libc                : libc-2.19.so\n");
output_string(buffer);
