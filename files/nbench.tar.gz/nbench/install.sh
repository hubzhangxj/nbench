
build_nbench()
{
    set -e
    ARCH=`uname -i`
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/tmp/nbench
    mkdir -p $myOBJPATH
    if [ $ARCH = "aarch32" ]; then
        make CFLAGS="-mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15"
    else
        make
    fi
}

build_nbench
